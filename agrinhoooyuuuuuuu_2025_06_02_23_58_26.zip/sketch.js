// Código atualizado com melhorias gráficas e realocação de carros a cada nova fase

let carros = [];
let trator;
let itens = [];
let cones = [];
let pontos = 0;
let perdeu = false;
let estado = 'inicio';
let maiorPontuacao = 0;
let fase = 1;

function setup() {
  createCanvas(800, 400);
}

function draw() {
  if (estado === 'inicio') {
    telaInicial();
  } else if (estado === 'jogo') {
    jogar();
  } else if (estado === 'fim') {
    telaFim();
  }
}

function telaInicial() {
  background(135, 206, 235);
  textAlign(CENTER);
  textSize(36);
  fill(0);
  text("Missão Campo-Cidade", width / 2, height / 2 - 20);
  textSize(18);
  text("Clique para começar", width / 2, height / 2 + 20);
}

function mousePressed() {
  if (estado === 'inicio') iniciarJogo();
}

function iniciarJogo() {
  carros = [];
  itens = [];
  cones = [];
  trator = new Trator(50, 320);
  if (fase === 1) {
    // Nenhum carro na fase 1 além do trator
  } else {
    for (let i = 0; i < 3; i++) {
      carros.push(new Carro(random(-200, -50), random(310, 370), random(['yellow', 'gray', 'red'])));
    }
  }
  pontos = 0;
  perdeu = false;
  estado = 'jogo';
}

function jogar() {
  background(135, 206, 235);

  if (fase === 1) {
    // Grama
    fill(34, 139, 34);
    rect(0, 300, width, 100);

    // Árvores
    for (let i = 50; i < width; i += 100) {
      fill(139, 69, 19);
      rect(i, 250, 20, 50);
      fill(34, 139, 34);
      ellipse(i + 10, 240, 60, 60);
    }

    // Sol
    fill(255, 204, 0);
    ellipse(80, 80, 50, 50);

    // Mensagem explicativa (acima das árvores)
    fill(0);
    textSize(16);
    textAlign(CENTER);
    text("Colha o máximo de trigo e leite e leve para o mercado municipal da cidade!", width / 2, 200);

    // Personagem agricultor
    let px = 200, py = 330;
    fill(245, 222, 179); // pele bege
    ellipse(px, py - 30, 20, 20);
    fill(255, 255, 0);
    arc(px, py - 32, 25, 20, PI, 0);
    fill(255, 0, 0);
    rect(px - 10, py - 20, 20, 20);
    fill(0, 0, 255);
    rect(px - 10, py, 20, 20);
    fill(0, 128, 0);
    ellipse(px - 4, py - 32, 3, 3);
    ellipse(px + 4, py - 32, 3, 3);
  } else {
    fill(50);
    rect(0, 300, width, 100);

    fill(169, 169, 169);
    for (let i = 0; i < 3; i++) {
      let offset = i * 70;
      rect(400 + offset, 150 - i * 20, 60, 150 + i * 20);
      rect(50 + offset, 150 - i * 20, 60, 150 + i * 20);
    }
  }

  for (let carro of carros) {
    carro.mover();
    carro.mostrar();
    if (carro.colide(trator)) {
      perdeu = true;
      estado = 'fim';
      if (pontos > maiorPontuacao) maiorPontuacao = pontos;
    }
  }

  for (let i = itens.length - 1; i >= 0; i--) {
    itens[i].mostrar();
    if (itens[i].colide(trator)) {
      pontos += itens[i].tipo === 'trigo' ? 2 : 1;
      itens.splice(i, 1);
    }
  }

  if (fase >= 2 && frameCount % 180 === 0 && itens.length < 3) {
    let tipo = random(['trigo', 'leite']);
    let y = random(310, 370);
    let x, overlap;
    do {
      x = random(420, 750);
      overlap = cones.some(c => dist(c.x, c.y, x, y) < 30);
    } while (overlap);
    itens.push(new Item(x, y, tipo));
  }

  if (fase >= 2) {
    if (frameCount % 120 === 0 && cones.length < 6) {
      let x, y, overlap;
      do {
        x = random(420, 750);
        y = random(310, 370);
        overlap = itens.some(it => dist(it.x, it.y, x, y) < 30) || cones.some(c => dist(c.x, c.y, x, y) < 30);
      } while (overlap);
      cones.push(new Cone(x, y));
    }

    for (let cone of cones) {
      cone.mostrar();
      if (cone.colide(trator)) {
        perdeu = true;
        estado = 'fim';
        if (pontos > maiorPontuacao) maiorPontuacao = pontos;
      }
    }
  }

  trator.mostrar();
  trator.mover();

  fill(0);
  textSize(18);
  textAlign(LEFT);
  text("Pontos: " + pontos, 10, 20);
  textAlign(RIGHT);
  text("Maior pontuação: " + maiorPontuacao, width - 10, 20);
  textAlign(CENTER);
  text("Fase: " + fase, width / 2, 20);

  if (trator.x > width) {
    pontos++;
    fase++;
    trator = new Trator(50, random(310, 370));

    // Reposiciona os carros a cada nova fase (exceto fase 1)
    if (fase > 1) {
      for (let i = 0; i < carros.length; i++) {
        carros[i].x = random(-200, -50);
        carros[i].y = random(310, 370);
      }
    }

    if (fase === 2) {
      carros = [];
      for (let i = 0; i < 3; i++) {
        carros.push(new Carro(random(-200, -50), random(310, 370), random(['yellow', 'gray', 'red'])));
      }
    }

    itens = [];
    cones = [];
  }
}

function telaFim() {
  background(0);
  fill('red');
  textAlign(CENTER);
  textSize(36);
  text("Game Over!", width / 2, height / 2 - 20);
  textSize(18);
  fill(255);
  text("Pontuação final: " + pontos, width / 2, height / 2 + 10);
  text("Pressione R para jogar de novo", width / 2, height / 2 + 40);
}

function keyPressed() {
  if (estado === 'fim' && (key === 'R' || key === 'r')) iniciarJogo();
}

class Trator {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.vel = 3;
  }

  mostrar() {
    // Corpo
    fill('#1E90FF');
    rect(this.x, this.y, 40, 20, 5);

    // Cabine
    fill('#87CEFA');
    rect(this.x + 10, this.y - 15, 20, 15, 3);

    // Escapamento
    fill(80);
    rect(this.x + 5, this.y - 10, 4, 10);

    // Rodas
    fill(0);
    ellipse(this.x + 5, this.y + 20, 12, 12);
    ellipse(this.x + 35, this.y + 20, 16, 16);
  }

  mover() {
    if (keyIsDown(UP_ARROW) && this.y > 300) this.y -= this.vel;
    if (keyIsDown(DOWN_ARROW) && this.y < 380) this.y += this.vel;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.vel;
  }
}

class Carro {
  constructor(x, y, cor) {
    this.x = x;
    this.y = y;
    this.cor = cor;
    this.velocidade = random(0.5, 1.5);
    this.fixado = false;
  }

  mover() {
    if (!this.fixado) {
      this.x += this.velocidade;
      if (this.x > width + 40) this.x = -60;
    }
  }

  mostrar() {
    fill(this.cor);
    rect(this.x, this.y, 40, 20, 4);
    fill(200);
    rect(this.x + 10, this.y + 4, 20, 8);
    fill('yellow');
    ellipse(this.x + 40, this.y + 5, 5, 5);
    fill(0);
    ellipse(this.x + 5, this.y + 20, 10, 10);
    ellipse(this.x + 35, this.y + 20, 10, 10);
  }

  colide(trator) {
    return (
      trator.x < this.x + 40 &&
      trator.x + 40 > this.x &&
      trator.y < this.y + 20 &&
      trator.y + 20 > this.y
    );
  }
}

class Item {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tipo = tipo;
    this.tam = 25;
  }

  mostrar() {
    if (this.tipo === 'trigo') {
      fill(255, 204, 100);
      beginShape();
      vertex(this.x + 6, this.y);
      vertex(this.x + 12, this.y + 8);
      vertex(this.x + 6, this.y + 16);
      vertex(this.x, this.y + 8);
      endShape(CLOSE);
    } else {
      fill(255);
      rect(this.x, this.y, 12, 20, 5);
      fill('blue');
      rect(this.x, this.y, 12, 5, 5);
    }
  }

  colide(trator) {
    return (
      trator.x < this.x + this.tam &&
      trator.x + 40 > this.x &&
      trator.y < this.y + this.tam &&
      trator.y + 20 > this.y
    );
  }
}

class Cone {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.largura = 16;
    this.altura = 20;
  }

  mostrar() {
    fill(255, 140, 0);
    triangle(this.x, this.y + this.altura, this.x + this.largura / 2, this.y, this.x + this.largura, this.y + this.altura);
    fill(255);
    rect(this.x + 3, this.y + 10, 10, 3);
    rect(this.x + 3, this.y + 15, 10, 3);
  }

  colide(trator) {
    return (
      trator.x < this.x + this.largura &&
      trator.x + 40 > this.x &&
      trator.y < this.y + this.altura &&
      trator.y + 20 > this.y
    );
  }
}
